function searchClick()
{
if(document.getElementById("search").value=="Search...")
document.getElementById("search").value="";
}

function searchClickOut()
{
if(document.getElementById("search").value=="")
document.getElementById("search").value="Search...";
}

function expand(s)
{
var td=s;
var p=td;
p.style.backgroundColor="#B4CFEC";
var d = td.getElementsByTagName("div").item(0);
d.style.display="block";
d.style.zIndex="10";
}

function contract(s)
{
var td=s;
var p=td;
p.style.backgroundColor="white";
var d = td.getElementsByTagName("div").item(0);
d.style.display="none";
}

function getDays(mon,yr)
{
if(mon==2)
		if((yr%100!=0 && yr%4==0) || yr%400==0) return 29;
		else return 28;
if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12)	return 31;
return 30;
}

function spaces(mon,yr)
{
var d1=new Date(""+yr+","+mon+",1");
return d1.getDay();
}

function month_change()
{
var mon=document.getElementById("month").value;
var j=0,i=0,row=1,ce=0;
var d = document.getElementById("cal").rows[1], e=d.cells;
for(j=0; j<42; j++,ce++)
{ if(j%7==0 && j!=0)
	{
	 row=row+1;
	 d = document.getElementById("cal").rows[row];
	 e=d.cells;
	 ce=0;
	}//</tr><tr>}
  e[ce].innerHTML=" ";//<td>i</td>
}
row=1; ce=0; d = document.getElementById("cal").rows[1]; e=d.cells;
for(j=0; j<spaces(mon,2012); j++, ce++);
{
e[j].innerHTML=" ";//<td></td>
}
for(i=1; i<=getDays(mon,2012);j++, i++, ce++)
{ if(j%7==0 && j!=0)
	{
	 row=row+1;
	 d = document.getElementById("cal").rows[row];
	 e=d.cells;
	 ce=0;
	}//</tr><tr>}
  e[ce].innerHTML=i;//<td>i</td>
}
}

var date_selected,temp_date;
function date_selected(s)
{
var yr=new Date();
temp_date=new Date;
temp_date.setFullYear(yr.getYear()+1900,document.getElementById("month").value-1,s);
var date_selected=(yr.getYear()+1900)+"-"+document.getElementById("month").value+"-"+s;
if(s!="" || s!=" "){
document.getElementById("date").innerHTML=date_selected;
document.getElementById("dat").innerHTML=document.getElementById("date").innerHTML
}else alert("null date");
toggleCalendar();
}

function toggleCalendar()
{
month_change();
if(document.getElementById("togCal").innerHTML=="Show Calendar")
	{
		document.getElementById("cal").style.display="inline-block";
		document.getElementById("togCal").innerHTML="Hide Calendar";
		document.getElementById("month").style.display="block";
	}
else {
		document.getElementById("cal").style.display="none";
		document.getElementById("togCal").innerHTML="Show Calendar";
		document.getElementById("month").style.display="none";
	}
}

function next(curr,nex,currnt,nextt)
{
document.getElementById(curr).style.display="none";
document.getElementById(nex).style.display="block";
document.getElementById(currnt).style.backgroundColor=document.getElementById("body").style.backgroundColor;
document.getElementById(currnt).style.color=document.getElementById("body").style.color;
document.getElementById(nextt).style.color="white";
document.getElementById(nextt).style.backgroundColor="#4863A0";
}

function click_in(t)
{
if(t.value=="Enter first 3 letters for suggestions") t.value="";
}

function click_out(t)
{
if(t.value=="") t.value="Enter first 3 letters for suggestions";
}

var xmlhttp;
function loadXMLDoc(url,cfunc)
{
if (window.XMLHttpRequest)  xmlhttp=new XMLHttpRequest();
else  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
xmlhttp.onreadystatechange=cfunc;
xmlhttp.open("GET",url,true);
xmlhttp.send();
}

var places;
function search(s,place)
{
if(place=="source_sugg") places="source";
else places="destination";
loadXMLDoc("ajax_bus_sd.jsp?stop="+s,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById(place).innerHTML=xmlhttp.responseText;
    }
  });
}

function sugg_onmouse(divitem)
{
divitem.style.backgroundColor="#B4CFEC";
divitem.style.cursor="pointer";
}

function sugg_outmouse(divitem)
{
divitem.style.backgroundColor=document.getElementById("body").style.backgroundColor;
divitem.style.color=document.getElementById("body").style.color;
divitem.style.cursor="default";
}

function sugg_click(s)
{
document.getElementById("source_sugg").innerHTML="";
document.getElementById("dest_sugg").innerHTML="";
document.getElementById(places).value=s;
}

var so,des,dat;
function step2()
{
so=document.getElementById("source").value;
des=document.getElementById("destination").value;
dat=document.getElementById("date").innerHTML;
if(so=="" || des=="" || dat=="" || so==dat)
{
alert("Check Please"); return false;
}
var yr=new Date();
if(yr>temp_date)
{
alert("Please select a proper date");
return false;
}

var url="ajax_bus_get.jsp?sour="+so+"&dest="+des+"&date="+dat;
loadXMLDoc(url,function()

  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("bus_table").innerHTML=rec;
    }
  });
  return true;
}

var bus_seat_count=0,bus_seat_arr=new Array(),selected_bus;
var sour_arr,dest_arr,sour_depart;
function step3()
{
var rad=document.getElementsByName("bus");
selected_bus=-1;
for(i=0; i<rad.length; i++)
if(rad[i].checked)
selected_bus=rad[i].value;
if(selected_bus==-1){alert("Select a bus, please"); return false;}
var str=document.getElementById("bus_tab").rows[selected_bus].cells[3].innerHTML;
"Arr: 08:00:00<hr>Dep: 08:30:00<hr>Dest Arr: 19:30:00<hr>Dist: 590.0kms"
sour_arr=str.substring(5,10); sour_depart=str.substring(22,27); dest_arr=str.substring(44,49);
var bus=document.getElementById("bus_tab").rows[selected_bus].cells;
document.getElementById("bus_company").innerHTML=bus[1].innerHTML;
document.getElementById("bus_no").innerHTML=bus[2].innerHTML;
document.getElementById("bus_type").innerHTML=bus[4].innerHTML;
document.getElementById("seat_type").innerHTML=bus[5].innerHTML;
document.getElementById("board").innerHTML=so;
document.getElementById("desti").innerHTML=des;
document.getElementById("fare").innerHTML=bus[9].innerHTML;
document.getElementById("depart_time").innerHTML=sour_depart;
document.getElementById("arr_tim").innerHTML=dest_arr;
var url="ajax_bus_seat.jsp?sour="+so+"&dest="+des+"&date="+dat+"&trans_comp="+bus[1].innerHTML+"&bus_no="+bus[2].innerHTML+"&no_of_seats="+bus[6].innerHTML+"&avail="+bus[8].innerHTML;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("seat_div").innerHTML=rec;
    }
  });
bus_seat_count=0;
bus_seat_arr=new Array();
return true;
}

function seat_select(img,path,i)
{
if(path.charAt(path.length-11)=='W')
{
img.src="G_chair.gif";
bus_seat_count+=1;
bus_seat_arr.push(parseInt(i));
bus_seat_arr.sort(sortfunc);
}
else if(path.charAt(path.length-11)=='G')
{
img.src="W_chair.gif";
bus_seat_count-=1;
bus_seat_arr.splice(bus_seat_arr.lastIndexOf(parseInt(i)),1);
bus_seat_arr.sort(sortfunc);
}
}

function sortfunc(a,b)
{
return a-b;
}

function step4()
{
if(bus_seat_count==0){alert("Select a seat, please"); return false;}
var r="<tr style='color:black;height:50px'><th>2</th><th>10</th><th><input type='text' id='pass1uid'></th><th><input type='text' id='pass1name'></th><th><input type='text' id='pass1dob'></th></tr>"
var tab=document.getElementById("bus_pass_det");
var i;var j=0;
for(i=1; i<tab.rows.length; i++){ tab.deleteRow(i); i--; }
for(i=1; i<=bus_seat_count; i++)
{
var row=tab.insertRow(tab.rows.length);
row.style.color="black";
row.style.height="50px";
var cell1=row.insertCell(0); cell1.innerHTML=i; cell1.style.textAlign="center";
var cell2=row.insertCell(1); cell2.innerHTML=bus_seat_arr[j++]; cell2.style.textAlign="center";
var cell3=row.insertCell(2);
var element1 = document.createElement("input"); element1.type = "text"; element1.id="pass"+i+"uid"; cell3.appendChild(element1);
cell3.style.textAlign="center";
var cell4=row.insertCell(3);
var element2 = document.createElement("input"); element2.type = "text"; element2.id="pass"+i+"name"; cell4.appendChild(element2);
cell4.style.textAlign="center";
var cell5=row.insertCell(4);
var element3 = document.createElement("input"); element3.type = "text"; element3.id="pass"+i+"dob"; cell5.appendChild(element3);
cell5.style.textAlign="center";
}
return true;
}


function step5()
{
var url="ajax_bus_pass.jsp?seat_count="+bus_seat_count;
var i,j;
for(i=1; i<=bus_seat_count; i++)
url=url+"&pass"+i+"uid="+document.getElementById("pass"+i+"uid").value+"&pass"+i+"name="+document.getElementById("pass"+i+"name").value+"&pass"+i+"dob="+document.getElementById("pass"+i+"dob").value;
loadXMLDoc(url,function()
{
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    if(xmlhttp.responseText!="")
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else {
    	if(rec=="Invalid") {alert("Invalid details"); return;} 
		else {var url1="ajax_bus_pay.jsp?seat_count="+bus_seat_count+"&fare="+document.getElementById("fare").innerHTML;
		for(i=1; i<=bus_seat_count; i++) url1=url1+"&pass"+i+"uid="+document.getElementById("pass"+i+"uid").value;
		loadXMLDoc(url1,function()
		{
  			if (xmlhttp.readyState==4 && xmlhttp.status==200)
    			{
    			document.getElementById("repeat5").innerHTML=document.getElementById("repeat").innerHTML;
    			var rec=xmlhttp.responseText;
    			if(rec=="false") window.open("index.jsp","_self");
    			else {document.getElementById("correct").innerHTML=rec;
    			var tab1=document.getElementById("pay_table");
    			for(j=1; j<tab1.rows.length; j++)
    			tab1.rows[j].cells[1].innerHTML=bus_seat_arr[j-1];
    			next("step4","step5","stp4","stp5");}
    			}
    	});
    	}
    	}
    }
    else alert("Error in details");
    }
  });
}

function step6()
{
if(!confirm("Confirm Transaction?")) return;
document.getElementById("repeat6").innerHTML=document.getElementById("repeat56").innerHTML;
var url="ajax_bus_final.jsp?seat_count="+bus_seat_count+"&tot_fare="+document.getElementById("tot_fare").innerHTML;
url+="&sour="+so+"&dest="+des+"&date="+dat+"&dept_time="+sour_depart+"&bus_no="+document.getElementById("bus_no").innerHTML+"&trans_comp="+document.getElementById("bus_company").innerHTML;
for(i=1; i<=bus_seat_count; i++) url=url+"&pass"+i+"uid="+document.getElementById("pass"+i+"uid").value;
for(i=1; i<=bus_seat_count; i++) url=url+"&pass"+i+"seat="+bus_seat_arr[i-1];
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else {document.getElementById("ticket_no").innerHTML=rec;
    next('step5','step6','stp5','stp6');}
    }
  });
}

function getbill(s)
{
if(document.getElementById("accno").value=="")
{alert("Please enter account number");
return;
}
var url="ajax_getbill.jsp?accno="+document.getElementById("accno").value+"&bill_type="+s;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("bill").innerHTML=rec;
    }
  });
}

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

function paybill(s)
{
if(document.getElementById("amt").value=="") return;
if(parseFloat(document.getElementById("amt").value)<1.0 || !isNumber(document.getElementById("amt").value)) { alert("Enter proper value"); return;}
if(confirm("Confirm Bill Payment?")){
var url="ajax_paybill.jsp?bill_no="+document.getElementById("bill_no").value+"&bill_type="+s+"&amt="+document.getElementById("amt").value;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("bill").innerHTML=rec;
    }
  });
  }
}

var ticket_no,tot_fare;
function viewTicket(s,tf)
{
tot_fare=tf;
var url="ajax_get_bus_ticket.jsp?&ticket_no="+s+"&tot_fare="+tf;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("view_ticket").innerHTML=rec;
    }
  });
}

function cancelBus(s,t,r,u,v,w)
{
if(confirm("Confirm cancellation? Your account will be creditted with Rs. "+r)){
ticket_no=s;
var url="ajax_cancel_bus_ticket.jsp?&ticket_no="+s+"&pass_uid="+t+"&refund="+r+"&bus_no="+u+"&trans_comp="+v+"&date="+w;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else {
    if(rec=="All tickets cancelled"){ alert(rec); window.open("cancel_bus.jsp","_self");}
    else {alert(rec); viewTicket(ticket_no,tot_fare);}
    }
    }
  });
 }
}

function login(u,p)
{
if(document.getElementById(u).value=="" || document.getElementById(p).value==""){alert("Please fill both "+u+" and Password"); return;}
var url="";
if(u=="UID")
url="LoginVerify?uid="+document.getElementById(u).value+"&pass="+document.getElementById(p).value
else
url="LoginVerify?loginID="+document.getElementById(u).value+"&pass="+document.getElementById(p).value+"&type="+document.getElementById("type").value;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") alert("Invalid "+u+" and/or Password");
    else if(rec=="true") window.location.reload();
    else window.open(rec,"_self");
    }
  });
}

function pan_form()
{
var t=document.getElementById("app_type");
if(t.options[t.selectedIndex].value=="Indi")
{
document.getElementById("comp_form").style.display="none";
document.getElementById("indi_form").style.display="block";
}
else 
{
document.getElementById("indi_form").style.display="none";
document.getElementById("comp_form").style.display="block";
}
}

function pan_submit(type)
{
var url;
var rad;
if(type=="indi"){
if(document.getElementById("name_card").value=="" || document.getElementById("indi_income_source").value=="" || document.getElementById("indi_assessee_uid").value=="" || document.getElementById("indi_assessee_fname").value=="" || document.getElementById("indi_assessee_dob").value=="") {alert("Fill all details please."); return;}
rad=document.getElementsByName("addrforcomm");
var addr="";
if(rad[0].checked) addr="RESIDENTIAL";
else if(rad[1].checked) addr="OFFICE";
if(addr==""){alert("Select address for communication"); return;}
url="ajax_pan_submit.jsp?type=INDIVIDUAL"+"&name="+document.getElementById("name_card").value+"&add="+addr+"&ass_uid="+document.getElementById("indi_assessee_uid").value+"&ass_fname="+document.getElementById("indi_assessee_fname").value+"&ass_dob="+document.getElementById("indi_assessee_dob").value+"&date="+document.getElementById("dob").innerHTML;
url+="&income_source="+document.getElementById("indi_income_source").value;
}
else
{
rad=document.getElementsByName("comp_addrforcomm");
var addr="";
if(rad[0].checked) addr="RESIDENTIAL";
else if(rad[1].checked) addr="OFFICE";
if(addr==""){alert("Select address for communication"); return;}
var t=document.getElementById("year");
var date=t.options[t.selectedIndex].value;
t=document.getElementById("month");
date=date+"-"+t.options[t.selectedIndex].value;
t=document.getElementById("day");
date=date+"-"+t.options[t.selectedIndex].value;
url="ajax_pan_submit.jsp?type=COMPANY"+"&name="+document.getElementById("comp_name_card").value+"&add="+addr+"&ass_uid="+document.getElementById("comp_assessee_uid").value+"&ass_fname="+document.getElementById("comp_assessee_fname").value+"&ass_dob="+document.getElementById("comp_assessee_dob").value+"&date="+date+"&reg_no="+document.getElementById("reg_no").value;
url+="&org_name="+document.getElementById("comp_org_name").value+"&org_nature="+document.getElementById("comp_org_nature").value;
}
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("SpecialLogin.jsp","_self");
    else
    {
    	if(rec=="Invalid") alert("Invalid details");
    	else{
    	document.getElementById("main_part").innerHTML=rec;}
    }
    }
  });
}

function viewPAN(s)
{
var url="ajax_getPan.jsp?&ack_no="+s;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else document.getElementById("view_PAN").innerHTML=rec;
    }
  });
}

function generatePartyForm()
{
document.getElementById("party_no").style.display="none";
var s=document.getElementById("no_of_parties").value;
var tab=document.getElementById("party_tab");
var i;var j=0;
for(i=1; i<tab.rows.length; i++){ tab.deleteRow(i); i--; }
for(i=1; i<=parseInt(s); i++)
{
var row=tab.insertRow(tab.rows.length);
row.style.color="black";
row.style.height="50px";
var cell2=row.insertCell(0); cell2.innerHTML=i; cell2.style.textAlign="center";
var cell3=row.insertCell(1);
var element1 = document.createElement("input"); element1.type = "text"; element1.id="party"+i+"name"; element1.name="party"+i+"name"; cell3.appendChild(element1);
cell3.style.textAlign="center";
var cell4=row.insertCell(2);
var element2 = document.createElement("input"); element2.type = "file"; element2.id="party"+i+"symb"; element2.name="party"+i+"symb"; cell4.appendChild(element2);
cell4.style.textAlign="center";
}
document.getElementById("party_form").style.display="block";
}

function validatePartyForm()
{
var no_of_parties=parseInt(document.getElementById("no_of_parties").value);
for(i=1; i<=no_of_parties; i++)
{
	if(document.getElementById("party"+i+"name").value=="" || document.getElementById("party"+i+"symb").value=="")
		{
			alert("One or more empty fields");
			return false;
		}
}
var flag=false;
for(i=1; i<=no_of_parties; i++)
{
	var str=document.getElementById("party"+i+"symb").value.toUpperCase();
	var suffix=".JPG";
	var suffix2=".JPEG";
	var suffix3=".PNG";
    if(!(str.indexOf(suffix, str.length - suffix.length) !== -1 || str.indexOf(suffix2, str.length - suffix2.length) !== -1
    	|| str.indexOf(suffix3, str.length - suffix3.length) !== -1))
    {
    	if(!flag)
        alert("File type not allowed,\nAllowed files: jpg, jpeg and png");
        document.getElementById("party"+i+"symb").value="";
        flag=true;
    }
}
if(flag) return false;
return true;
}

function generateCandidateForm()
{
var s=document.getElementById("no_of_candis").value;
if(!isNumber(s) || parseInt(s)>10){ alert("Max 10 candidates can be added at a time"); return;}
document.getElementById("candi_no").style.display="none";
var url="ajax_get_candiForm.jsp?&no_of_candis="+s;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else
    {
    	document.getElementById("candi_form").innerHTML=rec;
    	document.getElementById("message").innerHTML="";
    	document.getElementById("candi_form").style.display="block";
    }
    }
  });
}

function validateCandidateForm()
{
var no_of_candis=parseInt(document.getElementById("no_of_candis").value);
for(i=1; i<=no_of_candis; i++)
{
	if(document.getElementById("candi"+i+"locality").value=="" || document.getElementById("candi"+i+"uid").value=="" || document.getElementById("candi"+i+"fname").value=="" || document.getElementById("candi"+i+"dob").value=="")
		{
			alert("One or more empty fields");
			return;
		}
var url="ajax_submit_candiForm.jsp?no_of_candis="+no_of_candis;
var i;
for(i=1; i<=no_of_candis; i++)
var url=url+"&candi"+i+"uid="+document.getElementById("candi"+i+"uid").value+"&candi"+i+"fname="+document.getElementById("candi"+i+"fname").value.toUpperCase()+"&candi"+i+"dob="+document.getElementById("candi"+i+"dob").value+"&candi"+i+"party="+document.getElementById("candi"+i+"party").options[document.getElementById("candi"+i+"party").selectedIndex].value+"&candi"+i+"locality="+document.getElementById("candi"+i+"locality").value;
loadXMLDoc(url,function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else
    {
    	if(rec=="Error")
    	{
    		document.getElementById("candi_no").style.display="none";
    		document.getElementById("message").innerHTML="Error in some details.";
    		document.getElementById("candi_form").style.display="block";
    	}
    	else
    	{
    		document.getElementById("candi_no").style.display="block";
    		document.getElementById("message").innerHTML="Candidates added successfully";
    		document.getElementById("candi_form").style.display="none";
    	}
    }
    }
  });
}
}

function vote(s)
{
var url="Voted?candi_uid="+s;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
	var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else
    {
    	if(rec=="done") window.open("vote.jsp","_self");
    	else document.getElementById("message").innerHTML=rec
    }
    }
  });
}

function fetch_citizen()
{
if(document.getElementById("citizen_uid").value==null || document.getElementById("citizen_uid").value=="")
{
	alert("Check entered UID");
	return;
}
var url="ajax_modify_getCitizen.jsp?citizen_uid="+document.getElementById("citizen_uid").value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
	var rec=xmlhttp.responseText;
    if(rec=="false") window.open("index.jsp","_self");
    else
    {
    	if(rec=="Invalid") document.getElementById("citizen_details").innerHTML="Invalid UID. Check and try again";
    	else if(rec=="Own") document.getElementById("citizen_details").innerHTML="You can not modify your own details.";
    	else document.getElementById("citizen_details").innerHTML=rec;
    }
    }
  });
}

function view_data()
{
var div_to_show=document.getElementById("data_to_modify").value;
document.getElementById("photo").style.display="none";
document.getElementById("personal").style.display="none";
document.getElementById("passport_form").style.display="none";
document.getElementById("dlicense").style.display="none";
document.getElementById("citizen_details_table").style.display="none";
document.getElementById(div_to_show).style.display="block";
}

function submit_details(s)
{
if(s=="photo")
{
	var str=document.getElementById("photo_file").value.toUpperCase();
	var suffix=".PNG";
    if(str.indexOf(suffix, str.length - suffix.length) == -1)
    {
    	alert("File type not allowed,\nAllowed files: png");
        document.getElementById("photo_file").value="";
        return false;
    }
}
document.getElementById(s).style.display="none";
}

function marital_status_changed()
{
if(document.getElementById("marital_status").value=="married")
document.getElementById("marriage_certi_row").style.display="inline";
else document.getElementById("marriage_certi_row").style.display="none";
}

function forgotpass()
{
if(document.getElementById("uid").value=="" || document.getElementById("email_id").value=="" || document.getElementById("dob").value=="" || document.getElementById("fname").value==""){alert("Please fill all details"); return;}
document.getElementById("sub_button").disabled=true;
var url="ForgotPass?uid="+document.getElementById("uid").value+"&email_id="+document.getElementById("email_id").value+"&fname="+document.getElementById("fname").value+"&dob="+document.getElementById("dob").value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
	var rec=xmlhttp.responseText;
    if(rec=="false") document.getElementById("message_login").innerHTML="Error in some details";
    else
    {
    	if(rec=="done") document.getElementById("message_login").innerHTML="A mail with your new password has been sent to the email id provided.";
    	else document.getElementById("message_login").innerHTML=rec
    }
    }
  });
}

function search_citizen()
{
if(document.getElementById("uid").value=="" && document.getElementById("locality_area").value=="" && document.getElementById("name").value==""){alert("Please fill at least one text box"); return;}
var url="ajax_searchCitizen.jsp?uid="+document.getElementById("uid").value+"&name="+document.getElementById("name").value+"&locality="+document.getElementById("locality_area").value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var rec=xmlhttp.responseText;
    	if(rec=="false") window.open("SpecialLogin.jsp","_self");
    	else document.getElementById("search_results").innerHTML=rec;
    }
 });
}

function acc()
{
var y=document.getElementById('enterbc');
var x=document.getElementById('enteruid');
if(x.value=="" && y.value=="") { alert("Enter one of the fields"); return;}
if(x.value!="" && y.value!="") { alert("Enter only one of the fields"); return;}
var url="ajax_create_acc.jsp?enteruid="+x.value+"&enterbc="+y.value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
var rec=xmlhttp.responseText;
if(rec=="Error") {alert("Invalid details entered"); document.getElementById('createacc').style.display='none';}
else
{
	var u=document.getElementById("uid"); var v=document.getElementById("birth_certi");
	if(y.value=="" && x.value!=""){ v.value=rec; u.value=x.value;}
	if(x.value=="" && y.value!=""){ u.value=rec; v.value=y.value;}
	u.readOnly=true; v.readOnly=true;
	document.getElementById('createacc').style.display='block';
}
}
});
}

function validatecreateAcc()
{
if(document.getElementById('fname').value=="" || document.getElementById('lname').value=="" || document.getElementById('dob').value=="" || document.getElementById('acc_bal').value=="" || document.getElementById('block_no').value=="" || document.getElementById('building').value=="" || document.getElementById('street').value=="" || document.getElementById('pin').value=="" ||
document.getElementById('locality_area').value=="" || document.getElementById('height').value=="" || document.getElementById('email_id').value=="" || document.getElementById('city').value=="" || document.getElementById('state').value=="" || document.getElementById('residing_since').value=="")
{
alert("One or more missing fields");
return false;
}
if(!(isNumber(document.getElementById('pin').value) && isNumber(document.getElementById('resi_phone').value) && isNumber(document.getElementById('mobile_phone').value) && isNumber(document.getElementById('annual_income').value) && isNumber(document.getElementById('acc_bal').value)))
{
alert("Wrong format of input");
return false;
}
if(document.getElementById("marital_status").value=="married" && document.getElementById('marriage_certi').value=="")
{
alert("Enter Marriage Certificate No")
return false;
}
var pass=0,dl=0;
if(document.getElementById("passport").value!="") pass=pass+1;
if(document.getElementById("passport_file_no").value!="") pass=pass+1;
if(document.getElementById("pass_expiry_date").value!="") pass=pass+1;
if(document.getElementById("pass_issue_date").value!="") pass=pass+1;
if(document.getElementById("place_issue").value!="") pass=pass+1;
if(pass>0 && pass<5)
{
alert("Fill all passport form fields");
return false;
}
if(document.getElementById("driving_license").value!="") dl=dl+1;
if(document.getElementById("COV").value!="") dl=dl+1;
if(document.getElementById("dl_issue_date").value!="") dl=dl+1;
if(document.getElementById("dl_expiry_date").value!="") dl=dl+1;
if(dl>0 && dl<4)
{
alert("Fill all Driving License form fields");
return false;
}
return true;
}

function validateFiles()
{
if(document.getElementById("photo").value=="" || document.getElementById("fingerprint").value=="" || document.getElementById("digital_sign").value=="" || document.getElementById("retina_scan").value=="")
{
alert("Upload all files please.");
return false;
}
var str=document.getElementById("photo").value.toUpperCase();
var suffix=".PNG";
if(str.indexOf(suffix, str.length - suffix.length) == -1)
{
alert("File type not allowed,\nAllowed files: png");
document.getElementById("photo").value="";
return false;
}
return true;
}

function addfaq()
{
q=document.getElementById("ques");
a=document.getElementById("ans");
if(q.value=="" || a.value=="") {alert("Fill both fields please."); return;}
var url="AddFaq?ques="+q.value+"&ans="+a.value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var rec=xmlhttp.responseText;
    	if(rec=="false") window.open("SpecialLogin.jsp","_self");
    	else
    	{
    		document.getElementById("message").innerHTML=rec;
    		document.getElementById("ques").value="";
    		document.getElementById("ans").value="";
    	}
    }
 });
}

function refill_citi_acc()
{
var citi_uid=document.getElementById("citi_uid");
var amt=document.getElementById("amount");
if(citi_uid.value=="" || amt.value=="") {alert("Fill both fields please."); return;}
if(!isNumber(amt.value) || parseFloat(amt.value)<1.0) {alert("Please give a proper amount to refill."); return;}
var conf=confirm("Confirm transacton? Account of citizen with UID="+citi_uid.value+" will be credited with Rs. "+amt.value);
if(conf)
{
var url="RefillAccGovt?citi_uid="+citi_uid.value+"&amt="+amt.value;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var rec=xmlhttp.responseText;
    	if(rec=="false") window.open("SpecialLogin.jsp","_self");
    	else
    	{
    		document.getElementById("message").innerHTML=rec;
    		document.getElementById("citi_uid").value="";
    		document.getElementById("amt").value="";
    	}
    }
 });
}
}

var ack_no;
function viewPanApp(a)
{
ack_no=a;
if(document.getElementById("Pan_details"+ack_no).style.display=="block")
{
document.getElementById("Pan_details"+ack_no).style.display="none"; return;
}
var url="ajax_getPAN.jsp?ack_no="+ack_no;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var rec=xmlhttp.responseText;
    	if(rec=="false") window.open("SpecialLogin.jsp","_self");
    	else
    	{
    		document.getElementById("Pan_details"+ack_no).style.display="block";
    		document.getElementById("Pan_details"+ack_no).innerHTML=rec;
    	}
    }
 });
}

function pan_app_tab()
{
if(document.getElementById("what_to_see").value!="select")
{
document.getElementById("indi").style.display="none";
document.getElementById("comp").style.display="none";
document.getElementById(document.getElementById("what_to_see").value).style.display="block";
}
}

function status_change(s,ack_num)
{
if(s.value=="APPROVED") document.getElementById(ack_num+"_panBox").style.display="block";
else document.getElementById(ack_num+"_panBox").style.display="none";
}

function changePANstatus(ack_num)
{
var url="ChangePanStatus?ack_no="+ack_num+"&status="+document.getElementById(ack_num+"_status").value;
if(document.getElementById(ack_num+"_status").value=="APPROVED")
{
var pan=document.getElementById(ack_num+"_panBox").value;
if(pan=="" || pan.length<10)
	{
		alert("Please provide a valid PAN for the approved application.");
		return;
	}
url=url+"&pan="+document.getElementById(ack_num+"_panBox").value;
}
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		var rec=xmlhttp.responseText;
    	if(rec=="false") window.open("SpecialLogin.jsp","_self");
    	else
    	{
    		window.open("UpdatePanStatus.jsp","_self");
    	}
    }
 });
}

/*prachi-------------------------------------------------------------------*/

function creditcardval()
{
var amount=document.getElementById('amount').value;
if(amount=="") {alert("Enter amount");return false;}
else {
var x=document.getElementById("bankname");
var bankname=x.options[x.selectedIndex].value;
if(document.getElementById('amount').value==""||bankname==""||document.getElementById('cc').value==""||document.getElementById('cvv').value==""
||document.getElementById('expiry').value==""||document.getElementById('cardtype').value==""||document.getElementById('cardholder').value=="")
{alert("Empty fields");
return false;
}
else 
return true;
}

}


function challanvalidate()
{

var uid=document.getElementById('uid').value;
var msg="";
var radioButtons = document.forms['tax'].ded;
var rad=document.forms['tax'].paymenttype; 


for (var x = 0; x < radioButtons.length; x ++){
if (radioButtons[x].checked)
{
var b=radioButtons[x].id;
break;
}
}
if(x==radioButtons.length) msg+="**Select the company deduction";



if(document.forms['tax'].tan_no.value=="")
msg+="\n"+"**Fill the Tan No.";


if(document.forms['tax'].assyear.value=="")
msg+="**Fill the assessment year";


for (var y = 0; y < rad.length; y ++){
if (rad[y].checked)
{
var a=rad[y].id;
break;
}
}
if(y==rad.length) msg+="**Select the payment type";



if(msg=="") 
{
var ay=document.forms['tax'].assyear.value;
window.open('credit_card_tax.jsp?uid='+uid+'&assessment_year='+ay+'&payment_type='+a+'&payment_mode='+b,'_self');
}
else document.getElementById('error').innerHTML=msg;
}

function validatepassword()
{
var correct="correct";

var uid=document.getElementById('uid').value;
var opassword=document.getElementById('oldp').value;

var url='oldpassword.jsp?uid='+uid+'&opassword='+opassword;

loadXMLDoc(url,function() {
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{
var txt=xmlhttp.responseText;
if(txt.trim()==correct){
document.getElementById('newp').style.display='block';}
else
document.getElementById('newp1').innerHTML=txt;
}
});
}


function valpassword()
{
if(document.getElementById('pass').value!=""&&(document.getElementById('pass').value).length>6)
window.open('success_tax.jsp','_self');
else alert("Enter valid password");
}


function virtual(s)
{

document.getElementById('pass').value+=s;
}


function clearval()
{
var x=document.getElementById('pass').value;
document.getElementById('pass').value=x.substring(0,x.length-1);

}


function clearall()
{
document.getElementById('pass').value="";
}

function validatenewpassword()
{
document.getElementById('newp1').innerHTML="";
document.getElementById('message').innerHTML="";
var newpassword=document.getElementById('new').value;
var confirmpass=document.getElementById('confirmnew').value;
var uid=document.getElementById('uid').value;
if(newpassword==""||confirmpass=="")
alert("Enter both the values");

else if(newpassword!=confirmpass)
alert("Passwords dont match");


else if(newpassword==confirmpass&&confirmpass!=""&&newpassword!="")
{
var correct="correct";
var wrong="wrong";
var url='newpassword.jsp?newpassword='+newpassword+'&uid='+uid;

loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
var x=xmlhttp.responseText;
if(x=="correct"){
document.getElementById('message').innerHTML="your password has been changed successfully";
document.getElementById('newp').style.display='none';
}
else if(x=="wrong")
{
document.getElementById('message').innerHTML="your password was not changed.Try again later.";
document.getElementById('newp').style.display='none';
}
}
});
}

}


function validatepassword()
{
document.getElementById('newp1').innerHTML="";
document.getElementById('message').innerHTML="";
var correct="correct";

var uid=document.getElementById('uid').value;
var opassword=document.getElementById('oldp').value;

var url='oldpassword.jsp?uid='+uid+'&opassword='+opassword;

loadXMLDoc(url,function() {
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{
var txt=xmlhttp.responseText;
if(txt.trim()==correct){
document.getElementById('newp').style.display='block';}
else
{
document.getElementById('newp1').innerHTML=txt;
document.getElementById('newp').style.display='none';
}
}
});
}

function getApp_passport()
{
var x=document.getElementById('app_no').value;
var url='status_app_passport.jsp?application_no='+x;
if(x!="")
{
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{
var txt=xmlhttp.responseText;

if(txt!='1')
{
document.getElementById('app_form').innerHTML=txt;
}
else{
document.getElementById('app_form').innerHTML="No application was found with the entered number. Please check again.";

}
}

});

}

}


function ecno()
{
var ec=document.getElementById("ec_no");
if(ec!="")
document.getElementById("ec_details").style.display='block';
else
document.getElementById("ec_details").style.display='none';
}


function passport_form_val()
{
var val=1,ecnr;
var x=document.getElementById('formname').value;
var ec=document.getElementsByName('ec');
for(var i=0;i<ec.length;i++)
if(ec[i].checked)
{
ecnr=ec[i].value;
}

if(x=='renewal')
{
if(document.getElementById('ec_no').value!=""&&document.getElementById('place_issue_ec').value==""&&document.getElementById('reason').value==""&&document.getElementById('country_ec').value=="")
{
alert("Empty Emergency certificate Fields");
val=0;
}
}
if(x=='lost')
{
if(document.getElementById("fir").value=="")
{
alert("Empty Fields");
val=0;
}
}
if(val==1&&x=='renewal')
{
window.open('passport_2.jsp?formname=renew&ec_no='+document.getElementById('ec_no').value+'&place_issue_ec='+document.getElementById('place_issue_ec').value+'&reason='+document.getElementById('reason').value+'&country_ec='+document.getElementById('country_ec').value+'&ecnr='+ecnr,'_self');
}else if(val==1&&x!='renewal')

window.open('passport_2.jsp?formname='+x+'&ecnr='+ecnr,'_self');
}

function getPassportTime()
{
var confirm="your appointment has been successfully registered for the following day:";

var date=document.getElementById("cal_date").value;
var formname=document.getElementById("formname").value;
if(date=="")
{
alert("Select a date");
}


else{
var url='get_passport_time.jsp?date='+date+'&formname='+formname;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{
var x=xmlhttp.responseText;
if(x.trim()!='not available'){
var time=x+":00:00";
var url_app='Appointment_passport.jsp?date='+date+'&formname='+formname+'&time='+time;
if(x==12)
document.getElementById('time').innerHTML=confirm+"<br>"+"Date of Appointment :"+date+"<br>"+"Time of Appointment :"+xmlhttp.responseText+" pm";
if(x<12)
document.getElementById('time').innerHTML=confirm+"<br>"+"Date of Appointment :"+date+"<br>"+"Time of Appointment :"+xmlhttp.responseText+" am";
else if(x>12) document.getElementById('time').innerHTML=confirm+"<br>"+"Date of Appointment :"+date+"<br>"+"Time of Appointment :"+x%12+" pm";
window.open(url_app);



}
else if(x.trim()=='not available')
document.getElementById('time').innerHTML="No appointment available on the date selected.Try for some other day";

}

});
}

}









function passport_form()
{
var x=document.getElementById('ren_los');

var fr=x.options[x.selectedIndex].value;

document.getElementById('formname').value=fr;
var url='renew_lost.jsp?get_form='+fr;

loadXMLDoc(url,function(){
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{
var txt=xmlhttp.responseText;
if(txt.trim()=="1")
{
document.getElementById('pass_form').style.display='none';
document.getElementById('pass_form1').innerHTML="Sorry, you cannot renew your passport.";
}

else if(txt.trim()=="2")
{
document.getElementById('pass_form').style.display='none';
document.getElementById('pass_form1').innerHTML="Sorry, you cannot apply for this kind of passport.";
}

else if(fr=="new"&& txt.trim()!="2")
{
document.getElementById('pass_form1').innerHTML="";
document.getElementById('pass_form').style.display='block';
}
else if(fr=='renewal')
{
document.getElementById('pass_form1').innerHTML="";
document.getElementById('additional').innerHTML=txt;
document.getElementById('pass_form').style.display='block';
}

else if(fr=='lost')
{
document.getElementById('pass_form1').innerHTML="";
document.getElementById('additional').innerHTML=txt;
document.getElementById('pass_form').style.display='block';
}
}
});
}





function confirm_payment()
{
var a=confirm('Are you sure you want to pay?');
if(a)
{

var url="check_balance.jsp";

loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
if((xmlhttp.responseText).trim()!=""){
window.open('flight_page_6.jsp','_self');}
else document.getElementById("payment").innerHTML="Amount in the account less for this transaction.Refill account.";
 
}
});

}

else window.open('flight_page_4.jsp','_self');

}


function check_uid(i)
{
var url="check_uid_flight.jsp?txtbox="+i;
var i=parseInt(i);
for(var j=1;j<=i;j++)
{
var u=document.getElementById("passenger"+j).value;
var meal=document.getElementsByName('meal');
for(var n=0;n<meal.length;n++)
if(meal[n].checked)
{
url+='&meal'+j+"="+meal[n].value;
break;
}
if(n==meal.length) alert("please select your  preference");
var wheelchair=document.getElementsByName('wheelchair');
for(var k=0;k<1;k++)
if(wheelchair[k].checked)
{
url+='&wheelchair'+j+'=yes';
break;
}
if(k==1)
url+='&wheelchair'+j+'=no';

var staff_attendant=document.getElementsByName('staff_attendant');
for(var m=0;m<1;m++)
if(staff_attendant[m].checked)
{
url+='&staff_attendant'+j+'=yes';
break;
}
if(m==1)
url+='&staff_attendant'+j+'=no';


url+="&passenger"+j+"="+u+"&dob"+j+"="+document.getElementById("dob"+j).value;
}
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4 && xmlhttp.status==200)
{
if(xmlhttp.responseText!="")
document.getElementById("msg").innerHTML=xmlhttp.responseText;
else document.getElementById("msg").innerHTML="entered uid is invalid.try again";
 
}
});
}




function flight1_val()
{
var trip="";
var val=1;
var t=document.getElementsByName('trip');
for(var i=0;i<t.length;i++)
{
if(t[i].checked)
trip=t[i].value;
}
var x=document.getElementById('source');
var source=x.options[x.selectedIndex].value;

var d=document.getElementById('dest');
var dest=d.options[d.selectedIndex].value;


var fc=document.getElementById('flight_class');
var f_class=fc.options[fc.selectedIndex].value;


var today=new Date();
if(today>temp_datepr){
alert("Date entered is incorrect ");val=0;}



if(document.getElementById('depart').value==""||trip==""||dest==""||source==""||f_class=="")
{val=0;
alert("Empty fields. ")
}

if(trip=='twotrip')
{
if(document.getElementById('return_date').value=="")
{val=0;
alert("Empty fields");

}

}
if(val==0) return false;
else
return true;

}



function round_trip()
{

var trip=document.getElementsByName("trip");
for(var i=0;i<trip.length;i++)
{if(trip[i].checked)
if(trip[i].id=="twotrip")
{
document.getElementById('_trip').style.display='block';
document.getElementById('_trip_ret').style.display='block';
document.getElementById('return_togcal').style.display='block';
}
else if(trip[i].id=="onetrip")
{
document.getElementById('_trip').style.display='none';
document.getElementById('_trip_ret').style.display='none';
document.getElementById('togCal1').style.display='none';
document.getElementById('return').value="";

}
}
}

var loca="",temp_datepr;
function date_selectedpr(s)
{
var yr=new Date();
if(s!="" || s!=" ")
{
document.getElementById(loca).value=(yr.getYear()+1900)+"-"+document.getElementById("month").value+"-"+s;
var yr=new Date();
temp_datepr=new Date;
temp_datepr.setFullYear(yr.getYear()+1900,document.getElementById("month").value-1,s);
}
else alert("null date");
toggleCalendarpr(loca);
}

function toggleCalendarpr(loc)
{loca=loc
month_change();
if(document.getElementById("togCal").innerHTML=="Show Calendar")
    {
        document.getElementById("cal").style.display="inline-block";
        document.getElementById("togCal").innerHTML="Hide Calendar";
        document.getElementById("month").style.display="block";
    }
else {
        document.getElementById("cal").style.display="none";
        document.getElementById("togCal").innerHTML="Show Calendar";
        document.getElementById("month").style.display="none";
    }
}

function confirm_cancel()
{
var a=confirm("Are you sure you want to cancel?");
if(a)
{
var flight_no=document.getElementById('flight_no').value;
var ticket_number=document.getElementById('ticket_number').value;
var source=document.getElementById('source').value;
var dest=document.getElementById('dest').value;
var depart=document.getElementById('depart').value;
var amount=document.getElementById('amount').value;

window.open('flight_cancel_3.jsp?flight_no='+flight_no+'&ticket_number='+ticket_number+'&source='+source+'&dest='+dest+'&depart='+depart+'&amount='+amount,'_self');   
}
else window.open('flight_cancel_1.jsp','_self');

}

function getVisaPlace()
{

var country=document.getElementById("country").value;

var url="get_visa_place.jsp?country="+country;

loadXMLDoc(url,function(){
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{

var x=xmlhttp.responseText;

if(x!=""){
document.getElementById('place1').innerHTML=xmlhttp.responseText;
document.getElementById('pl_time').style.display='block';

}
else
document.getElementById('place1').innerHTMl="Sorry your request could not be processed";

}

});
}



function getVisaTime()
{
var confirm="your appointment has been successfully registered for the following day:";

var date=document.getElementById("cal_date").value;
var country=document.getElementById("country").value;
var p=document.getElementById("place");
var place=p.options[p.selectedIndex].value;

if(place==""||date=="")
{
if(place=="")
alert("Select a place");
else if(date=="")
{
alert("Select a date");

}
else
alert("Select a place and date");


}
else{
var url='get_visa_time.jsp?date='+date+'&country='+country+'&place='+place;
loadXMLDoc(url,function(){
if(xmlhttp.readyState==4&&xmlhttp.status==200)
{

var x=xmlhttp.responseText;
if(x.trim()!='not available'&&x.trim()!='err'){
var time=x+":00:00";
var url_app='enter_app_details.jsp?date='+date+'&country='+country+'&place='+place+'&time='+time;

if(x==12)
document.getElementById('time').innerHTML=confirm+"<br>"+date+"<br>"+xmlhttp.responseText+":00 pm";
if(x<12)
document.getElementById('time').innerHTML=confirm+"<br>"+date+"<br>"+xmlhttp.responseText+":00 am";
else if(x>12) document.getElementById('time').innerHTML=confirm+"<br>"+date+"<br>"+x%12+" pm";
window.open(url_app);
}
else if(x.trim()=='not available')
document.getElementById('time').innerHTML="No appointment available on the date selected.Try on some other day";
else if(x.trim()=='err')
document.getElementById('time').innerHTML="You cannot apply for a visa now due to a prior appointment";
}

});
}
}

function appointment_visa()
{
var country=document.getElementById('country_name').value;
if(document.getElementById('rel').value==""||document.getElementById('tel').value==""||
document.getElementById('addr').value==""||document.getElementById('arr').value==""||
document.getElementById('person').value==""||document.getElementById('len').value=="")
alert("Empty fields");

else window.open('visa_appointment.jsp?country='+country,'_self');
}