

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import java.io.PrintWriter;

 public class LoginVerify extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
	public LoginVerify() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		boolean flag=true;
		if(session.getAttribute("uid")!=null) {flag=false;out.print("home.jsp");}
		else if(session.getAttribute("type")!=null) {flag=false;out.print("SpecialLogin");}
		if(flag){
		try{
			  ResultSet rset=null;
			  Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			  Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123" );
			  con.setAutoCommit(true);
			  int count=0;
			  String name="",uid="",type="";
			  Statement stmt = con.createStatement();
			  if(request.getParameter("type")!=null)
			  {
				  type=request.getParameter("type");
				  if(type.equals("Administrator")) type="admin";
				  else if(type.equals("IT Official")) type="IT_official";
				  else if(type.equals("Police Official")) type="Police";
				  else if(type.equals("Refill Official")) type="Refill";
				  rset=stmt.executeQuery("select * from "+type+" where login_id='"+request.getParameter("loginID")+"' and password='"+request.getParameter("pass")+"'");
				  while(rset.next()) {count++; uid=rset.getString("uid"); }
				  if(count==1)
				  {
					  session.setAttribute("type",type); session.setAttribute("spluid",uid);
					  rset=stmt.executeQuery("select fname from citizen where uid='"+uid+"' and password='"+request.getParameter("pass")+"'");
					  while(rset.next()) name=rset.getString(1);
					  session.setAttribute("name",name);
					  out.print("true");
				  }
				  else {session.invalidate();out.print("false");}
				  con.close();
			  }
			  else
			  {
				  type="citizen";
				  rset=stmt.executeQuery("select fname from citizen where uid='"+request.getParameter("uid")+"' and password='"+HashPassword.getHashPwd(request.getParameter("pass"))+"'");
				  while(rset.next()){count++; name=rset.getString(1);}
				  if(count==1)
			 	  {
					session.setAttribute("uid",request.getParameter("uid"));
					session.setAttribute("name",name);
					stmt.execute("insert into log(uid,start_timestamp) values('"+session.getAttribute("uid")+"', current timestamp)");
					out.print("true");
			  	  }
			  	  else {out.print("false");}
				  con.close();
			  }
		   	} catch(Exception ie){out.print(ie.toString());}}
	}  	
	
}