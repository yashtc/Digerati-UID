

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class for Servlet: ChangePanStatus
 *
 */
 public class ChangePanStatus extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
	public ChangePanStatus() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try{
			HttpSession session=request.getSession();
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			if(!session.getAttributeNames().hasMoreElements()) out.println("false");
			else{
					Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
					Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123" );
					Statement stmt = con.createStatement();
					con.setAutoCommit(false);
					stmt.execute("update PAN set check_status='"+request.getParameter("status")+"' where acknowledge_no="+request.getParameter("ack_no"));
					if(request.getParameter("status").equals("APPROVED"))
					{
						ResultSet rset=stmt.executeQuery("select applicant_uid,status_of_applicant from pan where acknowledge_no="+request.getParameter("ack_no"));
						rset.next();
						if(rset.getString("status_of_applicant").equals("INDIVIDUAL"))
							stmt.execute("update citizen set pan='"+request.getParameter("pan")+"' where uid='"+rset.getString("applicant_uid")+"'");
					}
					con.commit();
					con.close();
			} 
	}catch(Exception ie){response.getWriter().println(ie.toString());}

	}  	
}