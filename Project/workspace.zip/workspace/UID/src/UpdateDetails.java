

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;

public class UpdateDetails extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet
{
   static final long serialVersionUID = 1L;
	public UpdateDetails()
	{
		super();
	}   	

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.sendRedirect("modify_details.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession session=request.getSession();
		if(session.getAttribute("type")==null || !session.getAttribute("type").toString().equalsIgnoreCase("Moderator")) response.sendRedirect("SpecialLogin.jsp");
		else{
		PrintWriter out=response.getWriter();
		try{
			response.setContentType("text/plain");
			boolean addr_flag=false;
			boolean name_flag=false;
			ResultSet rset=null;
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
			Statement stmt = con.createStatement();
			Statement stmt2= con.createStatement();
			con.setAutoCommit(false);
			rset=stmt2.executeQuery("select * from citizen where uid='"+request.getParameter("citi_uid")+"'");
			rset.next();
			if(!rset.getString("fname").equals(request.getParameter("fname").toUpperCase()))
			{
				String field="fname";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				name_flag=true;
			}
			if(!rset.getString("mname").equals(request.getParameter("mname").toUpperCase()))
			{
				String field="mname";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				name_flag=true;
			}
			if(!rset.getString("lname").equals(request.getParameter("lname").toUpperCase()))
			{
				String field="lname";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				name_flag=true;
			}
			if(name_flag)
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', 'NAME', current date, current time,'"+rset.getString("fname").toUpperCase()+" "+rset.getString("mname").toUpperCase()+" "+rset.getString("lname").toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			if(!rset.getString("gender").equals(request.getParameter("gender").toUpperCase()))
			{
				String field="gender";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("educational_quali").equals(request.getParameter("educational_quali").toUpperCase()))
			{
				String field="educational_quali";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("marital_status").equals(request.getParameter("marital_status").toUpperCase()))
			{
				String field="marital_status";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("annual_income").equals(request.getParameter("annual_income").toUpperCase()))
			{
				String field="annual_income";
				stmt.execute("update citizen set "+field+"="+Double.parseDouble(request.getParameter(field))+" where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field)+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("caste").equals(request.getParameter("caste").toUpperCase()))
			{
				String field="caste";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("religion").equals(request.getParameter("religion").toUpperCase()))
			{
				String field="religion";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("occupa_prof").equals(request.getParameter("occupa_prof").toUpperCase()))
			{
				String field="occupa_prof";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("bloodgroup").equals(request.getParameter("bloodgroup").toUpperCase()))
			{
				String field="bloodgroup";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("height").equals(request.getParameter("height").toUpperCase()))
			{
				String field="height";
				stmt.execute("update citizen set "+field+"="+Integer.parseInt(request.getParameter(field))+" where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field)+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("email_id").equals(request.getParameter("email_id")))
			{
				String field="email_id";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field)+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field)+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("resi_phone").equals(request.getParameter("resi_phone").toUpperCase()))
			{
				String field="resi_phone";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("mobile_phone").equals(request.getParameter("mobile_phone").toUpperCase()))
			{
				String field="mobile_phone";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("birth_certi").equals(request.getParameter("birth_certi").toUpperCase()))
			{
				String field="birth_certi";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("marriage_certi").equals(request.getParameter("marriage_certi").toUpperCase()))
			{
				String field="marriage_certi";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("pan").equals(request.getParameter("pan").toUpperCase()))
			{
				String field="pan";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', '"+field.toUpperCase()+"', current date, current time,'"+rset.getString(field).toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			}
			if(!rset.getString("block_no").equals(request.getParameter("block_no").toUpperCase()))
			{
				String field="block_no";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("building").equals(request.getParameter("building").toUpperCase()))
			{
				String field="building";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("street").equals(request.getParameter("street").toUpperCase()))
			{
				String field="street";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("locality_area").equals(request.getParameter("locality_area").toUpperCase()))
			{
				String field="locality_area";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("city").equals(request.getParameter("city").toUpperCase()))
			{
				String field="city";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("state").equals(request.getParameter("state").toUpperCase()))
			{
				String field="state";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("pin").equals(request.getParameter("pin").toUpperCase()))
			{
				String field="pin";
				stmt.execute("update citizen set "+field+"="+Double.parseDouble(request.getParameter(field))+" where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("country_resi").equals(request.getParameter("country_resi").toUpperCase()))
			{
				String field="country_resi";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(addr_flag)
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', 'RESI_ADDRESS', current date, current time,'"+rset.getString("block_no").toUpperCase()+" "+rset.getString("building").toUpperCase()+" "+rset.getString("street").toUpperCase()+" "+rset.getString("locality_area").toUpperCase()+" "+rset.getString("city").toUpperCase()+" "+rset.getString("state").toUpperCase()+" "+rset.getString("pin").toUpperCase()+" "+rset.getString("country_resi").toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			addr_flag=false;
			if(!rset.getString("off_block_no").equals(request.getParameter("off_block_no").toUpperCase()))
			{
				String field="off_block_no";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_building").equals(request.getParameter("off_building").toUpperCase()))
			{
				String field="off_building";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_street").equals(request.getParameter("off_street").toUpperCase()))
			{
				String field="off_street";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_locality_area").equals(request.getParameter("off_locality_area").toUpperCase()))
			{
				String field="off_locality_area";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_city").equals(request.getParameter("off_city").toUpperCase()))
			{
				String field="off_city";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_state").equals(request.getParameter("off_state").toUpperCase()))
			{
				String field="state";
				stmt.execute("update citizen set "+field+"='"+request.getParameter(field).toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(!rset.getString("off_pin").equals(request.getParameter("off_pin").toUpperCase()))
			{
				String field="off_pin";
				stmt.execute("update citizen set "+field+"="+Double.parseDouble(request.getParameter(field))+" where uid='"+request.getParameter("citi_uid")+"'");
				addr_flag=true;
			}
			if(addr_flag)
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"', 'OFF_ADDRESS', current date, current time,'"+rset.getString("off_block_no").toUpperCase()+" "+rset.getString("off_building").toUpperCase()+" "+rset.getString("off_street").toUpperCase()+" "+rset.getString("off_locality_area").toUpperCase()+" "+rset.getString("off_city").toUpperCase()+" "+rset.getString("off_state").toUpperCase()+" "+rset.getString("off_pin").toUpperCase()+"','"+session.getAttribute("spluid")+"')");
			con.commit();
			con.close();
			response.sendRedirect("modify_details.jsp?msg=success");
		}catch(Exception e){response.sendRedirect("modify_details.jsp?msg=error");}
		}
	}
}