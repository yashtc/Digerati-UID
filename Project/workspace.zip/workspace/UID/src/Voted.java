

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class for Servlet: Voted
 *
 */
 public class Voted extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
   
	public Voted() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		if(!session.getAttributeNames().hasMoreElements()) out.println("false");
		else{
				Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
				Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123" );
				Statement stmt = con.createStatement();
				con.setAutoCommit(true);
				stmt = con.createStatement();
				String uid=session.getAttribute("uid").toString();
				String candi=request.getParameter("candi_uid");
				stmt.execute("Update candidate_details set no_of_votes=no_of_votes+1 where candidate_uid='"+candi+"'");
				stmt=con.createStatement();
				stmt.execute("insert into voterlist values('"+uid+"')");
				out.print("done");
				con.close();
				} 
		}catch(Exception ie){response.getWriter().println(ie.toString());}
	}
}