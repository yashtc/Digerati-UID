

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 public class UpdateLicense extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
	public UpdateLicense() {
		super();
	}   	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.sendRedirect("modify_details.jsp");
	}	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession session=request.getSession();
		if(session.getAttribute("type")==null || !session.getAttribute("type").toString().equalsIgnoreCase("Moderator")) response.sendRedirect("SpecialLogin.jsp");
		else{
		try{
			response.setContentType("text/plain");
			ResultSet rset=null;
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
			Statement stmt = con.createStatement();
			con.setAutoCommit(false);
			rset=stmt.executeQuery("select driving_license from citizen where uid='"+request.getParameter("citi_uid")+"'");
			rset.next();
			String old_lic="";
			if(!rset.getString(1).equalsIgnoreCase("NA") || !rset.getString(1).equalsIgnoreCase(""))
			{
				old_lic=rset.getString(1);
				stmt.execute("update License set status='CANCELLED' where license_no='"+old_lic+"'");
				stmt.execute("insert into history values('"+request.getParameter("citi_uid")+"','DRIVING LICENSE',current date, current time, '"+old_lic+"', '"+session.getAttribute("spluid")+"')");
			}
			stmt.execute("update citizen set driving_license='"+request.getParameter("license_no").toUpperCase()+"' where uid='"+request.getParameter("citi_uid")+"'");
			stmt.execute("insert into License values('"+request.getParameter("license_no").toUpperCase()+"','"+request.getParameter("license_type").toUpperCase()+"','"+request.getParameter("COV").toUpperCase()+"', '"+request.getParameter("issue_date")+"','"+request.getParameter("expiry_date")+"','"+request.getParameter("status").toUpperCase()+"')");
			con.commit();
			con.close();
			response.sendRedirect("modify_details.jsp?msg=success");
			}catch(Exception e){response.sendRedirect("modify_details.jsp?msg=error");}
		}
	}
}