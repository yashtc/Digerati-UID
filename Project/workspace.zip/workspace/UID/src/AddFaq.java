

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class AddFaq extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet
 {
   static final long serialVersionUID = 1L;
   
	public AddFaq()
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		try{
			response.setContentType("text/plain");
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
			Statement stmt = con.createStatement();
			con.setAutoCommit(false);
			stmt.execute("Insert into faq values('"+request.getParameter("ques")+"', '"+request.getParameter("ans")+"')");
			out.println("The FAQ has been successfully added");
			con.commit();
			con.close();
			}catch(Exception e){out.println("Could not add FAQ due to some error");}

	}
}