

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForgotPass extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet
 {
   static final long serialVersionUID = 1L;
   
   public ForgotPass()
	{
		super();
	}
   
   public String getPass()
   {
	   String pass="";
	   String alpha[]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	   Random r=new Random();
	   for(int i=0; i<8; i++)
	   {
		   int alpha_num=r.nextInt(2);
		   if(alpha_num==0) pass=pass+r.nextInt(10);
		   else
		   {
			   pass=pass+alpha[r.nextInt(52)];
		   }
	   }
	   return pass;
   }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try{
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123" );
			Statement stmt = con.createStatement();
			con.setAutoCommit(true);
			stmt = con.createStatement();
			ResultSet rset=stmt.executeQuery("select count(uid) from citizen where uid='"+request.getParameter("uid")+"' and email_id='"+request.getParameter("email_id")+"' and fname='"+request.getParameter("fname").toUpperCase()+"' and dob='"+request.getParameter("dob")+"'");
			rset.next();
			String new_pass="";
			if(rset.getInt(1)==1)
			{
				new_pass=getPass();
				stmt.execute("update citizen set password='"+HashPassword.getHashPwd((new_pass))+"' where uid='"+request.getParameter("uid")+"'");
				MyMail m=new MyMail("New Password");
				m.send(request.getParameter("email_id"), new_pass);
				out.print("done");
			}
			else
			{
				out.print("false");
			}
			con.close(); 
		}catch(Exception ie){response.getWriter().println(ie.toString());}
	}
}