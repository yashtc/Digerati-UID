import javax.servlet.http.*;
import java.util.Date;
import java.sql.*;
public class LogManager implements HttpSessionListener {
	
	
    public void sessionCreated(HttpSessionEvent event) {
    	
    }
    public void sessionDestroyed(HttpSessionEvent event) {
    	try{
    	Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
    	Connection con=DriverManager.getConnection("jdbc:db2://localhost:50000/test","yashinst","tgmc123");;
    	Statement stmt=con.createStatement();
    	stmt.execute("update log set end_timestamp = current timestamp where uid='"+event.getSession().getAttribute("uid")+"'");
        System.out.printf("Session ID %s destroyed at %s%n", event.getSession().getId(), new Date());
    	con.close();
    	}catch(Exception e){}
    }
}
