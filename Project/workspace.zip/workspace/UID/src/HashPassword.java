import java.security.*;
import java.math.*;

public class HashPassword {

	public static String getHashPwd(String inpass)throws Exception
	{
		MessageDigest md=MessageDigest.getInstance("MD5");
		md.update(inpass.getBytes(),0,inpass.length());
		return (new BigInteger(1,md.digest()).toString());
	}
}
