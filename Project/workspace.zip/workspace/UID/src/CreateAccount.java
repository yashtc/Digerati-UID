import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
 
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

import java.sql.*;
 
 
public class CreateAccount extends HttpServlet {

	public String getPass()
	   {
		   String pass="";
		   String alpha[]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		   Random r=new Random();
		   for(int i=0; i<8; i++)
		   {
			   int alpha_num=r.nextInt(2);
			   if(alpha_num==0) pass=pass+r.nextInt(10);
			   else
			   {
				   pass=pass+alpha[r.nextInt(52)];
			   }
		   }
		   return pass;
	   }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.sendRedirect("CreateAccount.jsp");
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	try {
		PrintWriter out = response.getWriter();
	    HttpSession session=request.getSession();
	    response.setContentType("text/plain");
	    Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
	    Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
	    con.setAutoCommit(false);
	    Statement stmt = con.createStatement();
	    String password=getPass();
	    String sql="Insert into citizen values('"+request.getParameter("uid")+"','"+request.getParameter("fname").toUpperCase()+"','"+request.getParameter("mname").toUpperCase()+"','"+request.getParameter("lname").toUpperCase()+"','"+HashPassword.getHashPwd((password))+"','"+request.getParameter("dob")+"','"+request.getParameter("gender").toUpperCase()+"','"+request.getParameter("father_name").toUpperCase()+"',"+request.getParameter("fatheruid").toUpperCase()+",'"+request.getParameter("mother_name").toUpperCase()+"',"+request.getParameter("motheruid")+",'"+request.getParameter("educational_quali").toUpperCase()+"','"+request.getParameter("bloodgroup").toUpperCase()+"','"+request.getParameter("pan").toUpperCase()+"','"+request.getParameter("passport").toUpperCase()+"','"+request.getParameter("driving_license").toUpperCase()+"','"+request.getParameter("birth_certi").toUpperCase()+"','"+request.getParameter("marriage_certi").toUpperCase()+"','"+request.getParameter("marital_status").toUpperCase()+"','"+request.getParameter("occupa_prof").toUpperCase()+"',"+request.getParameter("height")+",'"+request.getParameter("caste").toUpperCase()+"','"+request.getParameter("religion").toUpperCase()+"','"+request.getParameter("govt_job").toUpperCase()+"','"+request.getParameter("email_id")+"',"+request.getParameter("annual_income")+",'"+request.getParameter("visible_distinguishable_mark").toUpperCase()+"',current date,"+request.getParameter("acc_bal")+",'"+request.getParameter("block_no").toUpperCase()+"','"+request.getParameter("building").toUpperCase()+"','"+request.getParameter("street").toUpperCase()+"','"+request.getParameter("locality_area").toUpperCase()+"','"+request.getParameter("city").toUpperCase()+"','"+request.getParameter("state").toUpperCase()+"',"+request.getParameter("pin")+",'"+request.getParameter("off_block_no").toUpperCase()+"','"+request.getParameter("off_building").toUpperCase()+"','"+request.getParameter("off_street").toUpperCase()+"','"+request.getParameter("off_locality_area").toUpperCase()+"','"+request.getParameter("off_city").toUpperCase()+"','"+request.getParameter("off_state").toUpperCase()+"',"+request.getParameter("off_pin")+",'"+request.getParameter("country_resi").toUpperCase()+"','"+request.getParameter("residing_since")+"','"+request.getParameter("resi_phone")+"','"+request.getParameter("mobile_phone")+"')";
	    stmt.execute(sql);
	    if(request.getParameter("passport")!="")
	    	stmt.execute("insert into passport values('"+request.getParameter("passport").toUpperCase()+"','"+request.getParameter("passport_file_no").toUpperCase()+"','"+request.getParameter("pass_expiry_date")+"','"+request.getParameter("pass_issue_date")+"','"+request.getParameter("place_issue").toUpperCase()+"','"+request.getParameter("ECNR_stamp").toUpperCase()+"','"+request.getParameter("pass_status").toUpperCase()+"')");
	    if(request.getParameter("driving_license")!="")
	    	stmt.execute("insert into License values('"+request.getParameter("driving_license").toUpperCase()+"','"+request.getParameter("license_type").toUpperCase()+"','"+request.getParameter("COV").toUpperCase()+"', '"+request.getParameter("dl_issue_date")+"','"+request.getParameter("dl_expiry_date")+"','"+request.getParameter("dl_status").toUpperCase()+"')");
	    stmt.execute("insert into history values('"+request.getParameter("uid")+"','CREATE_ACCOUNT',current date, current time, 'NEW', '"+session.getAttribute("spluid")+"')");
	    stmt.execute("delete from CreateAccount where uid='"+request.getParameter("uid")+"'");
	    con.commit();
		MyMail m=new MyMail("Account Created");
		m.send(request.getParameter("email_id"), password);
		con.close();
		response.sendRedirect("CreateAccount.jsp?uid="+request.getParameter("uid"));
		}
		catch(Exception ex)
		{
			//log("Error encountered while uploading file",ex);
			response.getWriter().println(ex.toString());
		}
	}
}