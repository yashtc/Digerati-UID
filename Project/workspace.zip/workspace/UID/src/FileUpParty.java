import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
 
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import java.sql.*;
 
 
public class FileUpParty extends HttpServlet {
	private static final String TMP_DIR_PATH = "/tmp";
	private File tmpDir;
	private static final String DESTINATION_DIR_PATH ="/PartySymbols";
	private File destinationDir;
	private String realPath;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		tmpDir = new File(TMP_DIR_PATH);
		if(!tmpDir.isDirectory()) throw new ServletException(TMP_DIR_PATH + " is not a directory");
		realPath = getServletContext().getRealPath(DESTINATION_DIR_PATH);
		destinationDir = new File(realPath);
		if(!destinationDir.isDirectory()) throw new ServletException(DESTINATION_DIR_PATH+" is not a directory");
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.sendRedirect("add_party.jsp");
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	try {
		boolean flag=true;
		PrintWriter out = response.getWriter();
	    HttpSession session=request.getSession();
	    response.setContentType("text/plain");
	    out.println();
	    ResultSet rset=null;
	    Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
	    Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
	    con.setAutoCommit(true);
	    Statement stmt = con.createStatement();
	    DiskFileItemFactory  fileItemFactory = new DiskFileItemFactory ();
		fileItemFactory.setSizeThreshold(1*1*1);
		fileItemFactory.setRepository(tmpDir);
		ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
		List items = uploadHandler.parseRequest(request);
		Iterator itr = items.iterator();
		String party_name="";
		String err_party="The party(parties) ";
		while(itr.hasNext()) 
		{
			FileItem item = (FileItem) itr.next();
			if(item.isFormField())
			{
				party_name=item.getString();
				party_name=party_name.toUpperCase();
				rset=stmt.executeQuery("select count(*) from Party_Details where party_name='"+party_name+"'");
			    rset.next();
			    int no=rset.getInt(1);
			    if(no>0) flag=false;
			    else
			    {
			    	stmt=con.createStatement();
			    	stmt.execute("insert into Party_Details values('"+party_name+"')");
			    }

				if(!flag)
					err_party+=party_name+", ";
			}
			else
			{
				if(flag)
				{
					File file = new File(destinationDir,item.getName());
					item.write(file);
					file.renameTo(new File(destinationDir,party_name+".png"));
				}
			}
		}
		if(!flag)
		{
			err_party+=" is(are) duplicates";
			response.sendRedirect("add_party.jsp?msg="+err_party);
			//out.println("The party(parties) "+err_party+" is(are) duplicates");
		}
		else
		{
			response.sendRedirect("add_party.jsp?msg='Parties added successsfully'");
		}
		con.close();
		out.close();
		}
		catch(FileUploadException ex)
		{
			log("Error encountered while parsing the request",ex);
		} 
		catch(Exception ex)
		{
			log("Error encountered while uploading file",ex);
		}
	}
}