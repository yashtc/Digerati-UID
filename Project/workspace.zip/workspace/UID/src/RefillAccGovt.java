

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

public class RefillAccGovt extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet
 {
   static final long serialVersionUID = 1L;
   
	public RefillAccGovt()
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		try{
			HttpSession session=request.getSession();
			response.setContentType("text/plain");
			Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
			Connection con = DriverManager.getConnection( "jdbc:db2://localhost:50000/test", "yashinst","tgmc123");
			Statement stmt = con.createStatement();
			con.setAutoCommit(false);
			int transac_no=0;
			stmt.execute("update citizen set acc_bal=acc_bal+"+request.getParameter("amt")+" where uid='"+request.getParameter("citi_uid")+"'");
			stmt.execute("Insert into Transactions values(DEFAULT,'"+request.getParameter("citi_uid")+"',CURRENT TIME,CURRENT DATE,'REFILL_BY_GO',"+request.getParameter("amt")+",'CREDIT')");
			ResultSet rset=stmt.executeQuery("Select transaction_no from transactions where uid='"+request.getParameter("citi_uid")+"' order by date,time");
			while(rset.next()) transac_no=Integer.parseInt(rset.getString(1));
			stmt.execute("Insert into GovtPay values('"+session.getAttribute("spluid")+"', "+transac_no+")");
			out.println("The citizen's account has been successfully refilled.");
			con.commit();
			con.close();
			}catch(Exception e){out.println("Could not refill account. Some error may have occured");}

	}
}