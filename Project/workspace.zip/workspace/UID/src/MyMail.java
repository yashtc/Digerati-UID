import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class MyMail   {
 
	  String msg,subject;
  
 public MyMail(String subjct){
  super();
  subject=subjct;
  }
 
 
//REMOVE THIS TO TEST AS JAVA APPLICATION
 
public void send(String sendto, String pass) throws AddressException, MessagingException{
  //MyMail m =new MyMail();
	if(subject.equalsIgnoreCase("New Password"))
		msg="Your new password is: "+pass+"\nPlease go to uid-digerati.no-ip.org/Webtest and login with your UID and the above password."+	
		"\nIt is suggested that you change your password when you log in for the first time.\n\nThank you,\nTeam Digerati."+
		"\n\n\nNote: This is a system generated mail. Do not reply or send mails to the sender of this mail.";
	else if(subject.equalsIgnoreCase("Account Created"))
		msg="Congratulations. Your account has been created. Your password is: "+pass+"\nPlease go to uid-digerati.no-ip.org/Webtest and login with your UID and the above password."+	
		"\nIt is suggested that you change your password when you log in for the first time.\n\nThank you,\nTeam Digerati."+
		"\n\n\nNote: This is a system generated mail. Do not reply or send mails to the sender of this mail.";
	GmailSend(sendto, subject, msg);
 }
 
 
public boolean GmailSend  (String to,String subject,String messageText) throws AddressException, MessagingException{
   
String host="smtp.gmail.com", user="uid.digerati", pass="Tgmc123!@#";
 
       
String SSL_FACTORY ="javax.net.ssl.SSLSocketFactory";      
boolean sessionDebug = true;
Properties props = System.getProperties();
props.put("mail.host", host);
props.put("mail.transport.protocol.", "smtp");
props.put("mail.smtp.auth", "true");
props.put("mail.smtp.", "true");
props.put("mail.smtp.port", "465");
props.put("mail.smtp.socketFactory.fallback", "false");
props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
Session mailSession = Session.getDefaultInstance(props,null);
mailSession.setDebug(sessionDebug);
Message msg =new MimeMessage(mailSession);
//msg.setFrom(new InternetAddress(from));
 try
  {
   InternetAddress[] address = {new InternetAddress(to)};
 msg.setRecipients(Message.RecipientType.TO, address);
 msg.setSubject(subject);
 msg.setContent(messageText,"text/plain"); // use setText if you want to send text
 Transport transport = mailSession.getTransport("smtp");
 transport.connect(host, user, pass);
 transport.sendMessage(msg, msg.getAllRecipients());//WasEmailSent = true; // assume it was sent
 return true;
       
 }
 catch(Exception err) {
       
 //WasEmailSent = false; // assume it's a fail
 return false;
 //System.out.println("Error"+err.getMessage());
 }
         //transport.close();
 
 }
}