import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
 
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class CreateAccount2 extends HttpServlet {
	private static final String TMP_DIR_PATH = "/tmp";
	private File tmpDir;
	private static String DESTINATION_DIR_PATH ="/pics";
	private File destinationDir;
	private String realPath;
	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		tmpDir = new File(TMP_DIR_PATH);
		if(!tmpDir.isDirectory()) throw new ServletException(TMP_DIR_PATH + " is not a directory");
		realPath = getServletContext().getRealPath(DESTINATION_DIR_PATH);
		destinationDir = new File(realPath);
		if(!destinationDir.isDirectory()) throw new ServletException(DESTINATION_DIR_PATH+" is not a directory");
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.sendRedirect("CreateAccount.jsp");
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	try {
		PrintWriter out = response.getWriter();
	    HttpSession session=request.getSession();
	    response.setContentType("text/plain");
	    DiskFileItemFactory  fileItemFactory = new DiskFileItemFactory ();
		fileItemFactory.setSizeThreshold(1*1*1);
		fileItemFactory.setRepository(tmpDir);
		ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
		List items = uploadHandler.parseRequest(request);
		Iterator itr = items.iterator();
		int i=0;
		String citi_uid="";
		while(itr.hasNext()) 
		{
			i++;
			FileItem item = (FileItem) itr.next();
			if(item.isFormField())
			{
				citi_uid=item.getString().toUpperCase();
			}
			else
			{
					switch(i)
					{
						case 2:{DESTINATION_DIR_PATH="/pics"; break;}
						case 3:{DESTINATION_DIR_PATH="/fingerprint"; break;}
						case 4:{DESTINATION_DIR_PATH="/retina_scan"; break;}
						case 5:{DESTINATION_DIR_PATH="/digital_sign"; break;}
					}
					realPath = getServletContext().getRealPath(DESTINATION_DIR_PATH);
					destinationDir = new File(realPath);
					if(!destinationDir.isDirectory()) throw new ServletException(DESTINATION_DIR_PATH+" is not a directory");
					File file = new File(destinationDir,item.getName());
					item.write(file);
					if(DESTINATION_DIR_PATH.equals("/pics"))
						file.renameTo(new File(destinationDir,citi_uid+".png"));
					else
						file.renameTo(new File(destinationDir,citi_uid));
			}
		}
		response.sendRedirect("CreateAccount.jsp");
		}
		catch(FileUploadException ex)
		{
			log("Error encountered while parsing the request",ex);
		} 
		catch(Exception ex)
		{
			//log("Error encountered while uploading file",ex);
			response.getWriter().println(ex.toString());
		}
	}
}